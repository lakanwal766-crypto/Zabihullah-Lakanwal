# د درملتون مدیریت سیستم — د نصب لارښود

## دا لومړنۍ نسخه څه لري؟
- د یو کارن Login (د Django کارن حساب)
- Dashboard، د درملو ثبت او لټون
- د Batch او ختمېدو نېټه
- عرضه کوونکي
- ساده خرڅلاو او د سټاک اتومات کمېدل
- ورځنی/میاشتنی خرڅلاو او اټکلي ګټه
- د موبایل او کمپیوټر لپاره Responsive ډیزاین

## په خپل کمپیوټر کې چلول
1. Python 3.11 یا نوې نسخه نصب کړئ.
2. ZIP فایل Extract کړئ او په همدې فولډر کې Terminal/Command Prompt خلاص کړئ.
3. مجازي چاپېریال جوړ کړئ:
   - Windows: `py -m venv .venv` بیا `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` بیا `source .venv/bin/activate`
4. کتابتونونه نصب کړئ: `pip install -r requirements.txt`
5. د ډیټابېس جدولونه جوړ کړئ: `python manage.py makemigrations pharmacy` او بیا `python manage.py migrate`
6. د خپل مدیر حساب جوړولو لپاره: `python manage.py createsuperuser`
7. سرور وچلوئ: `python manage.py runserver`
8. براوزر کې `http://127.0.0.1:8000` خلاص کړئ او د جوړ شوي کارن نوم/پاسورډ له لارې ننوتل وکړئ.

## د آنلاین سرور لپاره مهم
- `DEBUG=False` وټاکئ.
- اوږد او تصادفي `SECRET_KEY` وکاروئ.
- `ALLOWED_HOSTS` کې خپل domain ولیکئ.
- د PostgreSQL لپاره `DATABASE_URL` تنظیم کړئ.
- HTTPS، منظم بیک‌اپ، او د سرور امنیت فعال کړئ.
- `.env`، پاسورډونه او `db.sqlite3` عامه مه شریکوئ.

## د مهمو محدودیتونو یادونه
دا د پیل نسخه ده، نه بشپړ تایید شوی تجارتي سیستم. د پېرود/بستې پر بنسټ سټاک، د څو درملو په یوه رسید کې خرڅلاو، د بیرته ستنولو/پور مدیریت، او تفصیلي audit log لا نه دي پکې جوړ شوي. د درملتون د واقعي کارونې مخکې یې د نمونې معلوماتو سره وازمویئ، او د ختمېدو نېټې درمل مه خرڅوئ.

## د وړیا انلاین خپرولو لنډ لارښود (Render + PostgreSQL)
1. دا پروژه په خپل GitHub حساب کې د نوي repository په توګه پورته کړئ. د `.env`، پاسورډونو او شخصي ډیټابېس فایلونو شریکول مه کوئ.
2. د PostgreSQL داسې کوربه‌توب انتخاب کړئ چې د وړیا پلان د معلوماتو د ساتنې او مودې شرطونه یې درته مناسب وي؛ د connection string په راز کې وساتئ.
3. په Render کې New > Blueprint وټاکئ او د GitHub repository سره یې وصل کړئ؛ یا Web Service جوړ کړئ او Build Command `bash build.sh` او Start Command `gunicorn config.wsgi:application --bind 0.0.0.0:$PORT` وټاکئ.
4. د Render د Environment برخه کې `DATABASE_URL` د PostgreSQL connection string سره ډکه کړئ، `SECRET_KEY` اوږد او تصادفي وساتئ او `DEBUG=False` وټاکئ.
5. د Deploy له بشپړېدو وروسته د حساب جوړولو لپاره د Django shell/console یا د کوربه‌توب د ملاتړ شوې one-off command له لارې `python manage.py createsuperuser` اجرا کړئ. که وړیا پلان shell نه لري، د حساب جوړولو لپاره د خپل کمپیوټر له خوندي محلي چاپېریاله د production database سره د لنډمهاله خوندي اتصال یا د کوربه‌توب بله مناسبه طریقه وکاروئ؛ خپل پاسورډ له چا سره مه شریکوئ.

**مهم:** د Render وړیا ویب‌خدمت د ۱۵ دقیقو بې‌فعالیت وروسته ویده کېږي، او د Render وړیا PostgreSQL ډیټابېس د ۳۰ ورځو وروسته ختمېږي. د درملتون واقعي معلومات په داسې وړیا ډیټابېس کې مه ساتئ چې د ختمېدو، بیک‌اپ او بیا رغونې شرایط یې نه وي معلوم. مخکې له واقعي کارونې منظم بیک‌اپ او د معلوماتو د بېرته راګرځولو ازموینه حتمي ده.
